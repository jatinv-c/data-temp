package project.Match_Game;

import java.util.Arrays;
import java.util.List;

public class Singleton {

	private static Singleton singleton = null;
	
	private String[] arr = {"animal cell", "bear","deer","earth", "jupiter", "lily", "mercury", "saturn", "sunflower", "uranus", "venus"};
	
	private Singleton(){
		
	}
	
	public static Singleton getInstance()
    {
        if (singleton == null)
        	singleton = new Singleton();
 
        return singleton;
    }
	
	public List<String> getImageNameList(){
		return Arrays.asList(arr);
	}
}
