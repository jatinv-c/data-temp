package project.Match_Game;

import java.util.List;

import javafx.event.Event;
import javafx.scene.Parent;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Label;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Controller {

	View view;
	Model model;
	Parent root;
	
	private List<String> namelist;
	
	int correct = 0;
	int wrong = 0;
	
	public Controller() {
		
		namelist = Singleton.getInstance().getImageNameList();
		
		view = new View();
		
		view.controller = this;
		
		model = new Model();
		
		root = view.createUI();
		
		view.addImagesAndNamesToView(namelist);			
	}
	
	public Parent getRoot() {
		return root;
	}
	
	public void handleOnDragDetectedEvent(Label node, Event event) {
		System.out.println( "listcell setOnDragDetected" );
        Dragboard db = node.startDragAndDrop( TransferMode.COPY );
        ClipboardContent content = new ClipboardContent();
        content.putString( node.getText() );
        db.setContent( content );
        event.consume();
	}
	
	public void setOnDragDroppedEvents(Canvas canvas) {
		canvas.setOnDragEntered( event ->
        {        	
//            canvas.setStyle( "-fx-background-color: aqua;" );
            canvas.setStyle( "-fx-border-color: blue ;\r\n"
            		+ "            -fx-border-width: 5 ; \r\n"
            		+ "            -fx-border-style: segments(10, 15, 15, 15)  line-cap round ;" );
            
        } );

        canvas.setOnDragExited( event ->
        {
        	System.out.println("setOnDragExited() called");
//        	canvas.setStyle( "-fx-background-color: white;" );
        	canvas.setStyle( "-fx-border-color: transparent ;\r\n"
            		+ "            -fx-border-width: 0 ; \r\n"
            		+ "            -fx-border-style: segments(10, 15, 15, 15)  line-cap round ;" );
            
        } );

        canvas.setOnDragOver( event ->
        {
            Dragboard db = event.getDragboard();
            if ( db.hasString() )
            {
                event.acceptTransferModes( TransferMode.COPY_OR_MOVE );
            }
            event.consume();
        } );

        canvas.setOnDragDropped( event ->
        {
            System.out.println( "treeCell.setOnDragDropped" );
            Dragboard db = event.getDragboard();
            boolean success = false;
            if ( db.hasString() )
            {
            	if (canvas.getId().equals(db.getString())) {
            		correct++;
					view.namePane.getChildren().remove(event.getSource());
					System.out.println("*****************Right match");
					Label l = null;
					for (int i = 0; i < view.namePane.getChildren().size(); i++) {
						if (((Label)view.namePane.getChildren().get(i)).getText().equals(db.getString())) {
							l = (Label)view.namePane.getChildren().get(i);
							break;
						}						
					}
					view.namePane.getChildren().remove(l);
				}else {
					wrong++;
				}
            	
            	model.setCorrectGuess(correct);
            	model.setWronguess(wrong);
            	view.updateResult(correct, wrong);
            	checkForGameOver();
            	
                System.out.println( "Dropped: " + db.getString());
                success = true;
            }
            event.setDropCompleted( success );
            event.consume();
        } );
	}
	
	public void checkForGameOver() {
		System.out.println(model.isGameOver());
	}
}
