package project.Match_Game;

import java.io.File;
import java.util.List;

import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class View {

	VBox mainPane;
	TilePane imagePane;
	TilePane namePane;
	Controller controller;	
	
	Label resultLabel;
	
	public Parent createUI() {
		
		mainPane = new VBox();
		
        imagePane = new TilePane();		                     
        imagePane.setHgap(10);
        imagePane.setVgap(10);
        
        namePane = new TilePane();
        namePane.setHgap(10);
        namePane.setVgap(10);                
        
        HBox paneConatiner = new HBox();
        
        paneConatiner.getChildren().addAll(imagePane,namePane);
        
        resultLabel = new Label("Correct : 0\t\t\t Wrong : 0");
        resultLabel.setFont(new Font(30));
        
        mainPane.setSpacing(20);        
        mainPane.setPadding(new Insets(15));        
        mainPane.getChildren().addAll(paneConatiner, resultLabel);
        
		return mainPane;
	}
	
	public void addImagesAndNamesToView(List<String> list) {
		
		int IMAGE_SIZE = 100;
		
		for(String name : list) {
			
			Label label = new Label(name);
			
			label.setFont(new Font(20));
			
			label.setOnDragDetected(event -> controller.handleOnDragDetectedEvent(label, event));			
			
			namePane.getChildren().add(label);				
			
			Canvas canvas = new Canvas();
			
			canvas.setWidth(IMAGE_SIZE);
			
			canvas.setHeight(IMAGE_SIZE);
			
//			canvas.setStyle( "-fx-background-color: red;" );
			canvas.setStyle( "-fx-background-color: red ;\r\n"
					+ "    -fx-background-insets: 0, 20 ;\r\n"
					+ "    -fx-padding: 20 ;" );
            
			
			canvas.setId(name);
			
			controller.setOnDragDroppedEvents(canvas);
			
			GameObject gc = new GameObject(canvas.getGraphicsContext2D(), 0, 0);
			gc.img = new Image(new File(name + ".png").toURI().toString(), IMAGE_SIZE, IMAGE_SIZE, false, true);
			gc.update();
			
			imagePane.getChildren().add(canvas);
			
			
		}
	}
	
	public void updateResult(int correct, int wrong) {
		resultLabel.setText("Correct : " + correct + "\t\t\t Wrong : " + wrong);
	}
}
