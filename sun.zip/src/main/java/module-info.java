module project.Match_Game {
    requires javafx.controls;
    requires transitive javafx.fxml;

    exports project.Match_Game;
}
