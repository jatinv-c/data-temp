package game.fxapp;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Temp {

	public static void main(String[] args) {
		List<Integer[]> li = new ArrayList<>();
		int x = ThreadLocalRandom.current().nextInt(50,700);
		int y = ThreadLocalRandom.current().nextInt(180,400);
		System.out.println(li.add(new Integer[] {x,y}));
		
		Integer[] i= new Integer[] {x,y};
		if (li.contains(i)) {
			System.out.println("already there");
		}
		System.out.println(li.add(new Integer[] {x,y}));
	}

}
