package game.fxapp;

import java.io.File;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class OxygenImageObject extends GameObject implements Prototype{

	public OxygenImageObject(GraphicsContext gc, double x, double y) {
		super(gc, x, y);
		super.img = new Image(new File("oxygen.png").toURI().toString(), 100, 50, false, true);
	}

	@Override
	public void update() {		
		if (img != null) {            
            gc.drawImage(img, x, y, 100, 50);
        }
	}
	
	@Override
	public Object clone() {
		return this.clone();
	}
}
