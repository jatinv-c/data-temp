package game.fxapp;

import java.io.File;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class LargeTreeImageObject extends GameObject{

	public LargeTreeImageObject(GraphicsContext gc, double x, double y) {
		super(gc, x, y);
		super.img = new Image(new File("large-tree.png").toURI().toString(), 300, 400, false, true);
	}

	@Override
	public void update() {
		if (img != null) {           
            gc.drawImage(img, x, y, 300, 400);
        }
	}
}
