package game.fxapp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class ElementPrototypeFactory {

	final int NO_OF_OXYGEN_ELEMENTS = 10;
	final int NO_OF_CARBON_ELEMENTS = 10;
	
	private Map<Integer, OxygenCanvasObject> oxygenElementMap;
	private Map<Integer, CarbonCanvasObject> carbonElementMap;
	
	int[][] oxygenCoordiantedArr = {{ 70, 70 }, { 370, 70 }, { 220, 250 }, { 50, 400 }, { 550, 90 }, { 530, 430 }};
	int[][] carbonCoordiantedArr = { { 80, 210 }, { 240, 90 }, { 490, 510 }, { 590, 200 }, { 560, 350 } };
	List<Integer[]> oxygenIntArrList = new ArrayList<>();
	List<Integer[]> carbonIntArrList = new ArrayList<>();
	
	
	public ElementPrototypeFactory() {
		createOxygenElementsCordinates();		
		createObjectsForOxygenElements();
		
		createCarbonElementsCordinates();
		createObjectsForCarbonElements();
		
	}		
	
	private void createOxygenElementsCordinates() {
		for (int i = 0; i < NO_OF_OXYGEN_ELEMENTS; i++) {
			int randomX = ThreadLocalRandom.current().nextInt(50,700);
			int randomY = ThreadLocalRandom.current().nextInt(180,400);
			oxygenIntArrList.add(new Integer[] {randomX, randomY});
		}
	}	
	
	private void createObjectsForOxygenElements(){
		oxygenElementMap = new HashMap<>();
		for (int i = 0; i < oxygenIntArrList.size(); i++) {
			OxygenCanvasObject oxygenObject = new OxygenCanvasObject(100, 50, oxygenIntArrList.get(i)[0], oxygenIntArrList.get(i)[1]);			
			oxygenElementMap.put(i, oxygenObject);
		}
	}
	
	private void createCarbonElementsCordinates() {
		for (int i = 0; i < NO_OF_CARBON_ELEMENTS; i++) {
			int randomX = ThreadLocalRandom.current().nextInt(50,700);
			int randomY = ThreadLocalRandom.current().nextInt(180,400);
			carbonIntArrList.add(new Integer[] {randomX, randomY});
		}
	}
	
	private void createObjectsForCarbonElements(){
		carbonElementMap = new HashMap<>();
		for (int i = 0; i < oxygenIntArrList.size(); i++) {
			CarbonCanvasObject carbonObject = new CarbonCanvasObject(100, 50, carbonIntArrList.get(i)[0], carbonIntArrList.get(i)[1]);			
			carbonElementMap.put(i, carbonObject);
		}
	}
	
	public OxygenCanvasObject getOxygenCanvas(int index) {
		return oxygenElementMap.get(index).clone();
	}
	
	public CarbonCanvasObject getCarbonCanvas(int index) {
		return carbonElementMap.get(index).clone();
	}
	
	public int getOxygenArrSize() {
		return oxygenIntArrList.size();
	}
	
	public int getCarbonArrSize() {
		return carbonIntArrList.size();
	}
}
