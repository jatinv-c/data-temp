package com.game.View;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class GameView  {
	//handles UI elements for the game
	public ScrollPane sidePannel_Left;
	public ScrollPane sidePannel_Right;
	public StackPane  pannel_Center;
	public VBox vb_Left;
	public VBox vb_Right;
	public VBox vb_Center;

	public BorderPane root;
	
	public Text score;
	public GameView()
	{
		root = new BorderPane();
		vb_Left = new VBox();
		vb_Right = new VBox();
		vb_Center = new VBox();
		
		vb_Left.setAlignment(Pos.CENTER);
		vb_Right.setAlignment(Pos.CENTER);
		vb_Center.setAlignment(Pos.CENTER);
		
		vb_Left.setPadding(new Insets(10,10,10,0));
		vb_Right.setPadding(new Insets(10,10,10,0));

		pannel_Center = new StackPane(vb_Center);
		sidePannel_Left = new ScrollPane(vb_Left);
		sidePannel_Right = new ScrollPane(vb_Right);
		score = new Text("Score");
		score.setStyle("-fx-font: 30 arial;");

		sidePannel_Left.setFitToWidth(true);
		sidePannel_Right.setFitToWidth(true);
		sidePannel_Left.setMinSize(200, -1);
		sidePannel_Right.setMinSize(200, -1);
	}

}
