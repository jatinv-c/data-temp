package com.game.Model;

import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public abstract class Config {
	
	public static int screenWidth = 720;
	public static int screenHeight = 640;
	public static GameManager GManager;		//global object of GameManager class
	public static Stage MainStage;		//global object of Main Stage which will be shared across the entire game
	public static Scene HomeScene;
	
	public static String astronaut="Resource/astronaut.jpg";
	public static String astroid="Resource/astroid.jpg";
	public static String becteria="Resource/becteria.jpg";
	public static String blackhole="Resource/blackhole.jpg";
	public static String bloodvessel="Resource/bloodvessel.jpg";
	public static String brain="Resource/Brain.jpg";
	public static String earth="Resource/earth.jpg";
	public static String eyes="Resource/eyes.jpg";
	public static String hands="Resource/hands.jpg";
	public static String heart="Resource/heart.jpg";
	public static String ISS="Resource/ISS.jpeg";
	public static String kidney="Resource/kidney.jpg";
	public static String lungs="Resource/lungs.png";
	public static String meteor="Resource/meteor.jpg";
	public static String Microscope="Resource/Microscope.png";
	public static String mitrochondria="Resource/mitrochondria.jpg";
	public static String Moon="Resource/Moon.jpg";
	public static String neuron="Resource/neuron.jpg";
	public static String rbc="Resource/RBC.jpg";
	public static String rocket="Resource/rocket.png";
	public static String satalite="Resource/satalite.jpg";
	public static String skeleton="Resource/skeleton.jpg";
	public static String solarsystem="Resource/solarsystem.jpg";
	public static String spinalchord="Resource/spinalchord.jpg";
	public static String stomuch="Resource/stomuch.png";
	public static String sun="Resource/sun.jpg";
	public static String synapse="Resource/synapse.jpg";
	public static String teeth="Resource/teeth.jpg";
	public static String telescope="Resource/telescope.jpg";
	public static String WBC="Resource/WBC.jpg";
	
	public static Font fontB = Font.font("Arial", FontWeight.BOLD, 30);
	public static Font fontR = Font.font("Arial", FontWeight.NORMAL, 30);

}
