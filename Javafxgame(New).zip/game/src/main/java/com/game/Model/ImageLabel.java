package com.game.Model;

import java.io.File;
import java.io.FileInputStream;

import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class ImageLabel extends Rectangle {

	public String name;
	public ImageLabel(String Location,String objName) {
		// TODO Auto-generated constructor stub
		super();		
		
		name = objName;
	 	File theDir = new File("Resource");
	 	this.setStrokeWidth(5);
    	if (!theDir.exists()){
    	    theDir.mkdirs();
    	}
	    try 
	    {
	   
	    	FileInputStream f = new FileInputStream(Location);
	    	Image img = new Image(f);	
			this.setFill(new ImagePattern(img));
			
	    }catch(Exception e) 
	    {
	    	System.out.println("Error");
	    }
		
		this.setHeight(150);
		this.setOpacity(.8);
		this.setWidth(180);
		this.setStroke(Color.BLACK);
	}
	
	boolean findMatch(String stt) 
	{
		if(name.equals(stt) )
		{
			System.out.println("Match Found");
			return true;
		}else 
		{
			return false;
		}
	}
}
