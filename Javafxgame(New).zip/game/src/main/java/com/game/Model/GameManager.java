package com.game.Model;

public class GameManager {

	private boolean gameOver;
	private int totalScore;
	private int totalQuestion;
	//getters
	
	public boolean getGameOverState() 
	{
		return gameOver;
	}
	public int getScore() 
	{
		return totalScore;
	}
	public int gettotalQuestion() 
	{
		return totalQuestion;
	}
	//setters
	
	public void setGameOverState(boolean state) 
	{
		gameOver = state;
	}
	public void settotalQuestion(int totalQ) 
	{
		totalQuestion = totalQ;
	}
	public void setScore(int score) 
	{
		totalScore = score;
	}
}
