/**
 * 
 */
package com.game.Model;

import javafx.scene.Cursor;
import javafx.scene.ImageCursor;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

public class TextLabel  extends Text {

	/**
	 * 
	 */	
	public String name;
	public TextLabel(String str) {
		
		
		

		// TODO Auto-generated constructor stub
		this.setFont(Config.fontR);
		
		name = str;
		this.setText(str);
		this.addEventHandler(MouseEvent.MOUSE_ENTERED, event->
		{
			this.setCursor(Cursor.HAND);
			this.setFill(Color.ORANGE);
			this.setFont(Config.fontB);

		});
		
	
		this.addEventHandler(MouseEvent.MOUSE_DRAGGED, event->
		{
			this.setFill(Color.RED);

		});
		
		this.addEventHandler(MouseEvent.MOUSE_RELEASED, event ->{ 
			
			this.setCursor(Cursor.DEFAULT);
			this.setFill(Color.BLACK);

		});
		
		this.addEventHandler(MouseEvent.MOUSE_EXITED, event ->{ 
			
			this.setFill(Color.BLACK);
			this.setFont(Config.fontR);

		});

	}

}
