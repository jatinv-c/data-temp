package com.game.Model;

public interface Window {
	
	void Init();
	void update();
	void switchScene();
}

