package com.game.Controller;

import com.game.Model.Config;
import com.game.Model.GameManager;
import com.game.Model.ImageLabel;
import com.game.Model.Window;
import com.game.Model.TextLabel;
import com.game.View.GameView;

import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.Cursor;
import javafx.scene.ImageCursor;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

public class GamePanel implements Window {
	AnimationTimer gameloop;
	GameManager gameManager;
	TextLabel txtLabel ;
	String currSelection;
	String currImg;
	GameView gameWindow;
	public GamePanel()
	{
		 gameWindow = new GameView();
		gameWindow.root = new BorderPane();
		gameWindow.root.setStyle("-fx-background-color: #2f9f4f;");
		gameManager = new GameManager();
		gameManager.settotalQuestion(30);
		
	
		gameWindow.root.setLeft(gameWindow.sidePannel_Left);
		gameWindow.root.setRight(gameWindow.sidePannel_Right);
		gameWindow.root.setCenter(gameWindow.pannel_Center);

		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Blood Vessel")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Astroid")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Bacteria")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Black Hole")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Astronaut")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Brain")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Hands")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("ISS")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Meteoroid")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Kidney")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Mitochondrion")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Microscope")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Earth")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Neuron")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Moon")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Rocket")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Skeleton")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Solar System")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Satalite")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Spinal Cord")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Stomach")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Lungs")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Eyes")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Sun")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Synapse")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("WBC")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("RBC")));
		gameWindow.vb_Right.getChildren().add(addTextLabels(new TextLabel("Teeth")));

		gameWindow.vb_Center.getChildren().add(gameWindow.score);
		
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.astronaut,"Astronaut")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.astroid,"Astroid")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.becteria,"Bacteria")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.blackhole,"Black Hole")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.bloodvessel,"Blood Vessel")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.earth,"Earth")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.brain,"Brain")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.eyes,"Eyes")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.hands,"Hands")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.heart,"Heart")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.ISS,"ISS")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.lungs,"Lungs")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.kidney,"Kidney")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.meteor,"Meteoroid")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.Microscope,"Microscope")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.mitrochondria,"Mitochondrion")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.Moon,"Moon")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.neuron,"Neuron")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.rbc,"RBC")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.rocket,"Rocket")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.satalite,"Satalite")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.skeleton,"Skeleton")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.solarsystem,"Solar System")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.spinalchord,"Spinal Cord")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.stomuch,"Stomach")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.sun,"Sun")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.synapse,"Synapse")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.teeth,"Teeth")));
		gameWindow.vb_Left.getChildren().add(addImage(new ImageLabel(Config.WBC,"WBC")));


		
		Config.HomeScene = new Scene(gameWindow.root,Config.screenWidth,Config.screenHeight);
		Init() ; 
		gameloop.start();

	}
	
	ImageLabel addImage(ImageLabel img) 
	{
		
		img.setOnMouseDragReleased(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) 
			{
				//when label is dragged and dropped on image
				
				ImageLabel rec = (ImageLabel) event.getSource();

		           

		            if(currImg == currSelection) 
		            {
				            rec.setStrokeWidth(0);
			            	 rec.setDisable(true);
			            	 rec.setOpacity(.5);
			            	 gameManager.setScore(gameManager.getScore()+15);
			            	 gameManager.settotalQuestion(gameManager.gettotalQuestion()-1);
			            	 

		            }else 
		            {
		            	 gameManager.setScore(gameManager.getScore()-15);

		            	if(gameManager.getScore() <= 0) 
		            	{
			            	 gameManager.setScore(0);
		            	}

		            }
	         		gameWindow.score.setText("Score "+gameManager.getScore());
		            currImg = null;

			}
		});
		img.setOnMouseDragEntered(new EventHandler<MouseEvent>() {
		    @Override
		    public void handle(MouseEvent event) {
		    	
		    	currImg = img.name;
	            Rectangle rec = (Rectangle) event.getSource();
	            rec.setStroke(Color.ORANGE);
	            rec.setOpacity(1);

		    } 
		});
		img.setOnMouseDragExited(new EventHandler<MouseEvent>() {
		    @Override
		    public void handle(MouseEvent event) {
	            Rectangle rec = (Rectangle) event.getSource();
	            rec.setStroke(Color.BLACK);
	            rec.setOpacity(.8);
		    } 
		});
		return img;
	}
	TextLabel addTextLabels(TextLabel txt) {
		
		txt.addEventFilter(MouseEvent.DRAG_DETECTED,event->{
			txt.setCursor(Cursor.CLOSED_HAND);

			   final int padding = 40 ;
	            final int offset = 1 ;
	                Text text =txt;
	                currSelection = txt.getText();
	                Image textImage = text.snapshot(null, null);
	                int width = (int)textImage.getWidth();
	                int height = (int)textImage.getHeight();
	                WritableImage cursorImage = new WritableImage(width + offset, height + offset);
	                cursorImage.getPixelWriter().setPixels(offset, offset, width, height, textImage.getPixelReader(), 0, 0);
	                txt.setCursor(new ImageCursor(cursorImage));
			
		});
		txt.addEventFilter(MouseEvent.MOUSE_RELEASED, event->{
            currSelection = null;
		});
		return txt;
	}
	@Override
	public void Init() 
	{
		startGame() ;
	}
	private void startGame() 
	{
		gameloop = new AnimationTimer() {
			
			@Override
			public void handle(long now) {
				// TODO Auto-generated method stub
				update();
				
			}
		};
	}
	@Override
	public void update() {
		// TODO Auto-generated method stub
		//game loop
		if(gameManager.getGameOverState() == true) 
		{
			gameloop.stop();
			
		}
		if(gameManager.gettotalQuestion() <= 0) 
		{
			System.out.println("End of total Questions left");
			
     		gameWindow.score.setText("Game Finished \nTotal Score: "+gameManager.getScore());

			gameManager.setGameOverState(true);
		}
		
	}
	@Override
	public void switchScene() {
		// TODO Auto-generated method stub
		
	}


}
