package com.game;

import com.game.Controller.GamePanel;
import com.game.Model.Config;
import com.game.View.GameView;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 * JavaFX App
 */
public class App extends Application {

    @Override
    public void start(Stage stage) {
    	
		Config.MainStage = new Stage();	
		GamePanel game = new GamePanel();
		Config.MainStage.setScene(Config.HomeScene);
		Config.MainStage.setTitle("Game");
		Config.MainStage.show();
		
		Config.HomeScene.addEventFilter(MouseEvent.DRAG_DETECTED , new EventHandler<MouseEvent>() {
		    @Override
		    public void handle(MouseEvent mouseEvent) {
		    	Config.HomeScene.startFullDrag();
		    }
		});
    }

    public static void main(String[] args) {
        launch();
    }

}