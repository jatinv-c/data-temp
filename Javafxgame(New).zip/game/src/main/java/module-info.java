module com.game {
    requires javafx.controls;
	requires javafx.graphics;
	requires javafx.base;
    exports com.game;
}