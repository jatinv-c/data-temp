package game.fxapp;

import java.io.IOException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class HowToPlay {

	public Parent createHowToPlayUI() {
		
		Label titleLabel = new Label("How To Play!!");
		titleLabel.setFont(new Font(25));
		
		Label descriptionLabel = new Label();
		
		String desc = "1. The plant needs to be watered every 30 seconds for it to nourish and grow properly. Click on the watering can to water the plants."
				+ "\n\n2. The plant require Carbon Dioxide to grow. Click on the Oxygen and Carbon elements which appear randomly on the screen to give Oxygen and Carbon to the plant."
				+ "\n\n3. The plant also needs the sunlight to grow. The umbrella provides shade to the plant from excessive sunlight. To provide sunlight to the plant change the direction of the umbrella by clicking on it or pressing \"Q\" on the keyboard"
				+ "\n\n\nOnce the plant has sufficient resources it will grow to be a bigger palnt and eventually it will grow to be a tree. Your objective is to provide the necesary resources to the plant to help grow it into a tree";
		
		descriptionLabel.setText(desc);
		descriptionLabel.setWrapText(true);
		descriptionLabel.setPadding(new Insets(20,20,20,20));
		descriptionLabel.setFont(new Font(18));
		
		Button backButton = new Button("BACK");
		backButton.setFont(new Font(25));
		backButton.setPadding(new Insets(10,20,10,20));
		backButton.setOnAction(e -> {						
			try {
				App.setRoot(new Home().createHomeUI());
			} catch (IOException e1) {			
				e1.printStackTrace();
			}
		});
		
		VBox buttonContainer = new VBox(titleLabel,descriptionLabel,backButton);
		
		buttonContainer.setSpacing(20);
		
		BorderPane mainPane = new BorderPane(buttonContainer);
		buttonContainer.setAlignment(Pos.CENTER);
	
		return mainPane;
	}
	
}
