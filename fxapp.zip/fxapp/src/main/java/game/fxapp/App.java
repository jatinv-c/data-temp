package game.fxapp;

import java.io.IOException;

import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;


/**
 * JavaFX App
 */
public class App extends Application {

	public static Game game;
	public static Scene scene;
	
    @Override
    public void start(Stage stage) {        
      //initialize Game object and set it as default window
//        game = new Game();
        scene = new Scene(new Home().createHomeUI(), 800, 600);
        
        scene.setOnKeyPressed(e -> {
        	if (game != null) {
        		if(e.getCode() == KeyCode.Q) {
    				game.rotateUmbrella();
    			}    			
			}			
		});
        
        
        stage.setScene(scene);
        stage.show();
    }
        
    //to stop the threads in case user exits the game before it is over
    @Override
    public void stop() throws Exception {  
    	if (game != null) {
			game.gameOver = true;
		}    	
    	super.stop();
    }
    
    /**
     * change the current root window to whatever parent that is sent as method
     * parameter
     * can be called from anywhere in the application
     * @param parent - window to load
     * @throws IOException
     */
    static void setRoot(Parent parent) throws IOException {    	
        scene.setRoot(parent);
    }

    public static void main(String[] args) {
        launch();
    }

}