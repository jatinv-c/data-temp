package game.fxapp;

public interface Prototype {

	public Object clone();
}
