package game.fxapp;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicInteger;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

public class Game {

	Pane main;

	public final int TIME_PLANT_NEEDS_WATER_IN_SECONDS = 10;
	public final int NO_OF_TIMES_TO_SHOW_WATER_WARNING = 2;
	public final int SUNLIGHT_NEEDED_SECONDS = 30;
	public final int NO_OF_TIMES_TO_SHOW_SUNLIGHT_WARNING = 2;
	
	public final int UMBRELLA_ROTATION_ANGLE = 60;

	Canvas smallPlant;
	Canvas mediumTree;
	Canvas largeTree;
	Canvas wateringCanIV;
	Canvas waterdrops;
	Canvas sunIV;
	Canvas umbrellaIV;

	Image oxygenElement = new Image(new File("oxygen.png").toURI().toString(), 100, 50, false, true);
	Image carbonElement = new Image(new File("carbon.png").toURI().toString(), 100, 50, false, true);

	int noOfOxygenElClicked = 0;
	int noOfCarbonElClicked = 0;

	boolean isOxygenElementShown = false;
	boolean isCarbonElementShown = false;

	boolean isWatering = false;
	boolean isPlantWatered = false;

	// need thread safe integer
	AtomicInteger noOfSecondsPlantIsNotWatered = new AtomicInteger(0);
	
	AtomicInteger umbrellaAngle = new AtomicInteger(UMBRELLA_ROTATION_ANGLE);
	int noOfSecondsPlantGetsSunlight = 0;

	boolean isMediumTree = false;
	
	boolean gameOver = false;

	int[][] oxygenCoordiantedArr = { { 370, 70 }, { 220, 250 }, { 50, 400 }, { 550, 90 }, { 530, 430 }};
	int[][] carbonCoordiantedArr = { { 80, 210 }, { 240, 90 }, { 490, 510 }, { 590, 200 }, { 560, 350 } };

	Label warningMsg;
	Label sunlightMsg;
	
	OxygenImageObject oxygenImage;
	CarbonImageObject carbonImage;
	
	public Parent createGameUI() {

		main = new Pane();

		BackgroundImage myBI = new BackgroundImage(
				new Image(new File("bg.jpg").toURI().toString(), 800, 600, false, true), BackgroundRepeat.ROUND,
				BackgroundRepeat.SPACE, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

		main.setBackground(new Background(myBI));
		
		smallPlant = createAndGetCanvas("PLANT", 100, 100, 360, 400);

		// ************** Watering can starts ***************//
		wateringCanIV = createAndGetCanvas("WATERING_CAN", 150, 120, 160, 400);

		wateringCanIV.setCursor(Cursor.HAND);

		waterdrops = createAndGetCanvas("WATER_DROPS", 100, 100, 300, 400);
		waterdrops.setOpacity(0);
		waterdrops.toFront();

		KeyFrame startFadeOut = new KeyFrame(Duration.seconds(0.5), new KeyValue(waterdrops.opacityProperty(), 1.0));
		KeyFrame endFadeOut = new KeyFrame(Duration.seconds(0.5), new KeyValue(waterdrops.opacityProperty(), 0.0));

		Timeline t1 = new Timeline(startFadeOut, endFadeOut);
		t1.setCycleCount(4);

		wateringCanIV.setOnMouseClicked(e -> {
			if (!isWatering) {

				// set isWatering to true so user cannot click on watering can again till the
				// animation is over
				isWatering = true;
				
				playWateringSound();

				t1.play();

				t1.setOnFinished(ev -> {
					waterdrops.setOpacity(0);
					isWatering = false;
				});

				isPlantWatered = true;
				noOfSecondsPlantIsNotWatered.set(0);
			}
		});
		// ************** Watering can ends ***************//
		
		sunIV = createAndGetCanvas("SUN", 100, 100, 0, 0);
		umbrellaIV = createAndGetCanvas("UMBRELLA", 100, 100, 100, 100);
				
		umbrellaIV.setOnMouseClicked(e->{
			
			rotateUmbrella();
		});
		
		warningMsg = new Label();
		warningMsg.setPrefWidth(300);
		warningMsg.setTranslateX(460);
		warningMsg.setTranslateY(220);
		warningMsg.setWrapText(true);
//		warningMsg.setText("asdasdasdwqejiuwqdhnkajsnfkadsnflkasndlkfnlksdanflsdakfn");
		warningMsg.setFont(new Font(20));
		
		sunlightMsg = new Label();
		sunlightMsg.setPrefWidth(600);
		sunlightMsg.setTranslateX(160);
		sunlightMsg.setTranslateY(10);
		sunlightMsg.setWrapText(true);
//		sunlightMsg.setText("asdasdasdwqejiuwqdhnkajsnfkadsnflkasndlkfnlksdanflsdakfn");
		sunlightMsg.setFont(new Font(20));
		
		main.getChildren().addAll(smallPlant, wateringCanIV, waterdrops, sunIV, umbrellaIV, warningMsg, sunlightMsg);

//		showElements();
		startRandomElements();
		startPlantWaterCheck();
		startSunlightCheck();
		
		startBackgroundMusic();					
					
		return main;
	}
	
	public void rotateUmbrella() {
		Rotate rotate = new Rotate();
		
		rotate.setPivotX(10);
	    rotate.setPivotY(10);
	    
	    umbrellaIV.getTransforms().add(rotate);
	    
	    if (umbrellaAngle.get() == UMBRELLA_ROTATION_ANGLE) {
			rotate.setAngle(-UMBRELLA_ROTATION_ANGLE);
			umbrellaAngle.set(0);
		}else {
			rotate.setAngle(+UMBRELLA_ROTATION_ANGLE);
			umbrellaAngle.set(UMBRELLA_ROTATION_ANGLE);
		}
	}

	public void startRandomElements() {
		//Oxygen Element
		ImageView oxygenIV = new ImageView(oxygenElement);

		oxygenIV.setOnMouseClicked(e -> {
			System.out.println("Oxygen Element Clicked");
			main.getChildren().remove(oxygenIV);
			isOxygenElementShown = false;

			noOfOxygenElClicked++;

			checkForPlantChange();
		});	

		Thread oxygenElementThread = new Thread(new Runnable() {
			@Override
			public void run() {
				while (!gameOver) {
					try {
						Thread.sleep(5000);
						if (!isOxygenElementShown) {
							int randomNum = ThreadLocalRandom.current().nextInt(0, oxygenCoordiantedArr.length);

							oxygenIV.setTranslateX(oxygenCoordiantedArr[randomNum][0]);
							oxygenIV.setTranslateY(oxygenCoordiantedArr[randomNum][1]);

							isOxygenElementShown = true;
							Platform.runLater(() -> {
								main.getChildren().add(oxygenIV);							
							});
						}
						Thread.sleep(5000);

						// remove element if not clicked on for 5 seconds
						Platform.runLater(() -> {
							main.getChildren().remove(oxygenIV);
						});
						isOxygenElementShown = false;

					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				Platform.runLater(() -> {
					if (main.getChildren().contains(oxygenIV)) {
						main.getChildren().remove(oxygenIV);
					}
				});				
			}
		});

		oxygenElementThread.start();
		
		
		//Carbon element
		ImageView carbonIV = new ImageView(carbonElement);
		
		carbonIV.setOnMouseClicked(e -> {
			System.out.println("Oxygen Element Clicked");
			main.getChildren().remove(carbonIV);
			isOxygenElementShown = false;

			noOfCarbonElClicked++;

			checkForPlantChange();
		});	

		Thread carbonElementThread = new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				while (!gameOver) {
					try {
						Thread.sleep(5000);
						if (!isCarbonElementShown) {
							int randomNum = ThreadLocalRandom.current().nextInt(0, carbonCoordiantedArr.length);

							carbonIV.setTranslateX(carbonCoordiantedArr[randomNum][0]);
							carbonIV.setTranslateY(carbonCoordiantedArr[randomNum][1]);

							isOxygenElementShown = true;
							Platform.runLater(() -> {
								main.getChildren().add(carbonIV);							
							});
						}
						Thread.sleep(5000);

						// remove element if not clicked on for 5 seconds
						Platform.runLater(() -> {
							main.getChildren().remove(carbonIV);
						});
						isCarbonElementShown = false;

					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				Platform.runLater(() -> {
					if (main.getChildren().contains(carbonIV)) {
						main.getChildren().remove(carbonIV);
					}
				});	
				
			}			
		});

		carbonElementThread.start();
	}
	
	public void showElements() {
		
		for (int i = 0; i < carbonCoordiantedArr.length; i++) {
			ImageView oxygenIV = new ImageView(oxygenElement);
			oxygenIV.setTranslateX(oxygenCoordiantedArr[i][0]);
			oxygenIV.setTranslateY(oxygenCoordiantedArr[i][1]);
			main.getChildren().add(oxygenIV);
		}
		
		
		for (int i = 0; i < carbonCoordiantedArr.length; i++) {
			ImageView carbonIV = new ImageView(carbonElement);
			carbonIV.setTranslateX(carbonCoordiantedArr[i][0]);
			carbonIV.setTranslateY(carbonCoordiantedArr[i][1]);
			main.getChildren().add(carbonIV);
		}
		
		
		
	}

	public void startPlantWaterCheck() {
		Thread th = new Thread(() -> {
			// wait few seconds before starting the check for water
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			int noOfWarnings = 0;

			while (!gameOver) {
				try {
					Thread.sleep(1000);

					if (noOfSecondsPlantIsNotWatered.get() == 0) {
						noOfWarnings = 0;
					}
					noOfSecondsPlantIsNotWatered.getAndAdd(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				if (noOfSecondsPlantIsNotWatered.get() > 0
						&& noOfSecondsPlantIsNotWatered.get() % TIME_PLANT_NEEDS_WATER_IN_SECONDS == 0) {

					isPlantWatered = false;

					if (noOfWarnings < NO_OF_TIMES_TO_SHOW_WATER_WARNING) {
						System.out.println("The plant has not been watered.");
						
						Platform.runLater(()-> showMsg("The plant has not been watered."));
												
						noOfWarnings++;
					} else {
						System.out.println("GAME OVER");
						gameOver = true;
						
						Platform.runLater(()-> gameOver("The tree did not get enough water"));
						
					}

				}

			}
		});

		th.start();
	}
	
	public void startSunlightCheck() {
		Thread th = new Thread(() -> {
			int noOfWarning = 0;
			while(!gameOver) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {					
					e.printStackTrace();
				}
				if(umbrellaAngle.get() != UMBRELLA_ROTATION_ANGLE) {
					noOfSecondsPlantGetsSunlight++;
				}
				
				if (noOfSecondsPlantGetsSunlight > SUNLIGHT_NEEDED_SECONDS
						&& noOfSecondsPlantGetsSunlight % 20 == 0) {
																					
						if (noOfWarning > NO_OF_TIMES_TO_SHOW_SUNLIGHT_WARNING) {
							gameOver = true;							
							Platform.runLater(()-> gameOver("The tree died due to excessive sunlight."));						
						}else {							
							noOfWarning++;							
							showSunlightMsg();
						}					
				}
			}
		});
		th.start();
	}

	public void checkForPlantChange() {
		System.out.println("-----------------------");
		System.out.println(noOfOxygenElClicked);
		System.out.println(noOfCarbonElClicked);
		System.out.println(isPlantWatered);
		System.out.println(noOfSecondsPlantGetsSunlight);
		System.out.println("-----------------------");
		
		if (!isMediumTree && noOfOxygenElClicked >= 3 && noOfCarbonElClicked >= 3 && isPlantWatered 
				&& noOfSecondsPlantGetsSunlight > SUNLIGHT_NEEDED_SECONDS) {
//			gameOver = true;
			isMediumTree = true;
			isPlantWatered = false;
			noOfSecondsPlantGetsSunlight = 0;

			KeyFrame startFadeOut = new KeyFrame(Duration.seconds(0.2),
					new KeyValue(smallPlant.opacityProperty(), 1.0));
			KeyFrame endFadeOut = new KeyFrame(Duration.seconds(2.5), new KeyValue(smallPlant.opacityProperty(), 0.0));

			Timeline t1 = new Timeline(startFadeOut, endFadeOut);
			t1.play();
			t1.setOnFinished(et -> {
				main.getChildren().remove(smallPlant);
				
				mediumTree = createAndGetCanvas("MEDIUM_TREE", 100, 200, 360, 300);

				mediumTree.setOpacity(0);

				main.getChildren().add(mediumTree);
				waterdrops.toFront();

				KeyFrame keyFrame2On = new KeyFrame(Duration.seconds(0.5),
						new KeyValue(mediumTree.opacityProperty(), 0.0));
				KeyFrame endFadeIn = new KeyFrame(Duration.seconds(2.8),
						new KeyValue(mediumTree.opacityProperty(), 1.0));

				Timeline t2 = new Timeline(keyFrame2On, endFadeIn);
				t2.play();
			});

		}else if(isMediumTree && noOfOxygenElClicked >= 6 && noOfCarbonElClicked >= 6 && isPlantWatered 
				&& noOfSecondsPlantGetsSunlight > SUNLIGHT_NEEDED_SECONDS) {
			
			gameOver = true;
			
			KeyFrame startFadeOut = new KeyFrame(Duration.seconds(0.2),
					new KeyValue(mediumTree.opacityProperty(), 1.0));
			KeyFrame endFadeOut = new KeyFrame(Duration.seconds(2.5), new KeyValue(mediumTree.opacityProperty(), 0.0));

			Timeline t1 = new Timeline(startFadeOut, endFadeOut);
			t1.play();
			t1.setOnFinished(et -> {
				main.getChildren().remove(mediumTree);
				
				largeTree = createAndGetCanvas("LARGE_TREE", 300, 400, 260, 130);

				largeTree.setOpacity(0);

				main.getChildren().add(largeTree);
				waterdrops.toFront();

				KeyFrame keyFrame2On = new KeyFrame(Duration.seconds(0.5),
						new KeyValue(largeTree.opacityProperty(), 0.0));
				KeyFrame endFadeIn = new KeyFrame(Duration.seconds(2.8),
						new KeyValue(largeTree.opacityProperty(), 1.0));

				Timeline t2 = new Timeline(keyFrame2On, endFadeIn);
				t2.play();
				
				t2.setOnFinished(e -> {
					Platform.runLater(() -> showMsg("Congratulations!! You Won."));
				});
			});
		}
	}

	public Canvas createAndGetCanvas(String imageType, double width, double height, int x, int y) {

		Canvas canvas = new Canvas();

		GameObject imageObject = GameObjectFactory.getGameObject(imageType, canvas.getGraphicsContext2D());

		canvas.setHeight(height);
		canvas.setWidth(width);

		canvas.setTranslateX(x);
		canvas.setTranslateY(y);

		imageObject.update();

		return canvas;
	}
		
	public void startBackgroundMusic() {
//		Thread th = new Thread(() -> {
//			Media media = new Media(new File("bg-music.mp3").toURI().toString()); 
//			MediaPlayer mediaPlayer = new MediaPlayer(media);			
//			mediaPlayer.setCycleCount(javafx.scene.media.AudioClip.INDEFINITE);
//			mediaPlayer.setVolume(0.5f);
//			mediaPlayer.setAutoPlay(true);
//			MediaView mediaView = new MediaView(mediaPlayer);
//			Platform.runLater(() -> main.getChildren().add(mediaView));
//		});
//		th.start();
	}
	
	public void playWateringSound() {
//		Thread th = new Thread(() -> {
//			Media media = new Media(new File("watering-can-sound.mp3").toURI().toString()); 
//			MediaPlayer mediaPlayer = new MediaPlayer(media);			
//			mediaPlayer.setCycleCount(1);
//			mediaPlayer.seek(new Duration(4500));
//			mediaPlayer.setStartTime(new Duration(3500));
//			mediaPlayer.setAutoPlay(true);						
//			MediaView mediaView = new MediaView(mediaPlayer);
//			Platform.runLater(() -> main.getChildren().add(mediaView));
//		});
//		th.start();
	}	
	
	public void gameOver(String msg) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("Game Over !!!");
		alert.setHeaderText(null);
		alert.setContentText("You have lost the game !!\n" + msg);

		alert.showAndWait();
		try {
			App.setRoot(new Home().createHomeUI());
		} catch (IOException e) {			
			e.printStackTrace();
		}
	}
	
	
	public void showMsg(String msg) {
		KeyFrame startFadeOut = new KeyFrame(Duration.seconds(1.0),
				new KeyValue(warningMsg.opacityProperty(), 1.0));
		KeyFrame endFadeOut = new KeyFrame(Duration.seconds(6.5), 
				new KeyValue(warningMsg.opacityProperty(), 0.0));

		Timeline t1 = new Timeline(startFadeOut, endFadeOut);
		
		warningMsg.setText(msg);
		if (warningMsg.getText().toLowerCase().contains("won")) {
			warningMsg.setFont(new Font(35));
			warningMsg.setTextFill(Color.RED);
			t1.setCycleCount(-1);
		}
		
		Thread th = new Thread(() -> {
			t1.play();
			t1.setOnFinished(e -> {
				Platform.runLater(() -> {
					if (!warningMsg.getText().toLowerCase().contains("won")) {
						warningMsg.setText("");
					}
				});				
			});
		});		
		th.start();
	}
	
	public void showSunlightMsg() {
		KeyFrame startFadeOut = new KeyFrame(Duration.seconds(1.0),
				new KeyValue(sunlightMsg.opacityProperty(), 1.0));
		KeyFrame endFadeOut = new KeyFrame(Duration.seconds(6.5), 
				new KeyValue(sunlightMsg.opacityProperty(), 0.0));

		Timeline t1 = new Timeline(startFadeOut, endFadeOut);
		
		Platform.runLater(() -> {					
			sunlightMsg.setText("The plant will die if it will recieve sunlight for too long. Use the umbrella to block the sunlight.");					
		});				
		
		Thread th = new Thread(() -> {
			t1.play();
			t1.setOnFinished(e -> {
				Platform.runLater(() -> {					
					sunlightMsg.setText("");					
				});				
			});
		});		
		th.start();
	}
}
