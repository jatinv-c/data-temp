package game.fxapp;

import java.io.IOException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class Home {
	
	public Parent createHomeUI() {
					
		Button playButton = new Button("PLAY");
		playButton.setFont(new Font(25));
		playButton.setPadding(new Insets(10,20,10,20));
		playButton.setOnAction(e -> {			
			App.game = new Game();
			try {
				App.setRoot(App.game.createGameUI());
			} catch (IOException e1) {			
				e1.printStackTrace();
			}
		});
		
		Button howToButton = new Button("HOW TO PLAY");
		howToButton.setFont(new Font(25));
		howToButton.setPadding(new Insets(10,20,10,20));
		howToButton.setOnAction(e -> {						
			try {
				App.setRoot(new HowToPlay().createHowToPlayUI());
			} catch (IOException e1) {			
				e1.printStackTrace();
			}
		});
		
		VBox buttonContainer = new VBox(playButton, howToButton);
		
		buttonContainer.setSpacing(20);
		
		BorderPane mainPane = new BorderPane(buttonContainer);
		buttonContainer.setAlignment(Pos.CENTER);
	
		return mainPane;
	}
}
