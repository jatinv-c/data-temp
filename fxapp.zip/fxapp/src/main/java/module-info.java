module game.fxapp {
    requires javafx.controls;
    exports game.fxapp;
}
