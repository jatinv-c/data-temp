package project.Match_Game;

import java.util.List;

public class Model {

	private int correctGuess = 0;
	private int wronguess = 0;
	private List<String> namelist;
	
	public Model() {
		namelist = Singleton.getInstance().getImageNameList();
	}
	
	public int getCorrectGuess() {
		return correctGuess;
	}
	
	public void setCorrectGuess(int correctGuess) {
		this.correctGuess = correctGuess;
	}
	
	public int getWronguess() {
		return wronguess;
	}
	
	public void setWronguess(int wronguess) {
		this.wronguess = wronguess;
	}
		
	public boolean isGameOver() {
		if (getCorrectGuess() == namelist.size()) {
			System.out.println("Game Over");
			return true;
		}else {
			return false;
		}
	}
}
