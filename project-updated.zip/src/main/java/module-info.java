module game.fxapp {
    requires javafx.controls;
    requires transitive javafx.graphics;
	requires java.desktop;
	requires javafx.media;
	
    exports game.fxapp;
}
