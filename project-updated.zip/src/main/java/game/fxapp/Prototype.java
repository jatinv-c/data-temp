package game.fxapp;

public interface Prototype extends Cloneable{

	public Object clone();
}
