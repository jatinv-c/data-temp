package game.fxapp;

import java.util.HashMap;
import java.util.Map;

public class ElementPrototypeFactory {

	private Map<Integer, OxygenCanvasObject> oxygenElementMap;
	private Map<Integer, CarbonCanvasObject> carbonElementMap;
	
	int[][] oxygenCoordiantedArr = {{ 70, 70 }, { 370, 70 }, { 220, 250 }, { 50, 400 }, { 550, 90 }, { 530, 430 }};
	int[][] carbonCoordiantedArr = { { 80, 210 }, { 240, 90 }, { 490, 510 }, { 590, 200 }, { 560, 350 } };
	
	public ElementPrototypeFactory() {
		createObjectsForOxygenElements();
		createObjectsForCarbonElements();
	}		
	
	public void createObjectsForOxygenElements(){
		oxygenElementMap = new HashMap<>();
		for (int i = 0; i < oxygenCoordiantedArr.length; i++) {
			OxygenCanvasObject oxygenObject = new OxygenCanvasObject(100, 50, oxygenCoordiantedArr[i][0], oxygenCoordiantedArr[i][1]);			
			oxygenElementMap.put(i, oxygenObject);
		}
	}
	
	public void createObjectsForCarbonElements(){
		carbonElementMap = new HashMap<>();
		for (int i = 0; i < carbonCoordiantedArr.length; i++) {
			CarbonCanvasObject carbonObject = new CarbonCanvasObject(100, 50, carbonCoordiantedArr[i][0], carbonCoordiantedArr[i][1]);			
			carbonElementMap.put(i, carbonObject);
		}
	}
	
	public OxygenCanvasObject getOxygenCanvas(int index) {
		return oxygenElementMap.get(index).clone();
	}
	
	public CarbonCanvasObject getCarbonCanvas(int index) {
		return carbonElementMap.get(index).clone();
	}
}
