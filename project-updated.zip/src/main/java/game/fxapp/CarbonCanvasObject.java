package game.fxapp;

import javafx.scene.canvas.Canvas;

public class CarbonCanvasObject extends Canvas implements Prototype {

	CarbonImageObject carbonImageObject;

	public CarbonCanvasObject(int width, int height, int x, int y) {
		this.setTranslateX(x);
		this.setTranslateY(y);
		this.setHeight(height);
		this.setWidth(width);
		carbonImageObject = new CarbonImageObject(this.getGraphicsContext2D(), 0, 0);
		carbonImageObject.update();
	}

	@Override
	public CarbonCanvasObject clone() {
		Object clone = null;

		try {
			clone = super.clone();

		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}

		((CarbonCanvasObject) clone).carbonImageObject.update();
		return (CarbonCanvasObject) clone;
	}
}
