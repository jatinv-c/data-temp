package game.fxapp;

import java.io.File;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class WateringCanImageObject extends GameObject{

	public WateringCanImageObject(GraphicsContext gc, double x, double y) {		
		super(gc, x, y);
		super.img = new Image(new File("watering-can.png").toURI().toString(), 150,
				120, false, true);
	}

	@Override
	public void update() {
		if (img != null) {
            gc.drawImage(img, x, y, 150, 120);
        }
	}
}
