package game.fxapp;

import javafx.scene.canvas.GraphicsContext;

public class GameObjectFactory {

	public static GameObject getGameObject(String objectType, GraphicsContext gc) {
		
		if (objectType.equalsIgnoreCase("PLANT")) {
			return new PlantImageObject(gc, 0, 0);
			
		} else if(objectType.equalsIgnoreCase("MEDIUM_TREE")) {
			return new MediumTreeImageObject(gc, 0, 0);
			
		} else if(objectType.equalsIgnoreCase("LARGE_TREE")) {
			return new LargeTreeImageObject(gc, 0, 0);
			
		}  else if(objectType.equalsIgnoreCase("WATERING_CAN")) {
			return new WateringCanImageObject(gc, 0, 0);
			
		} else if(objectType.equalsIgnoreCase("OXYGEN")) {
			return new OxygenImageObject(gc, 0, 0);
			
		} else if(objectType.equalsIgnoreCase("CARBON")) {
			return new CarbonImageObject(gc, 0, 0);
			
		} else if(objectType.equalsIgnoreCase("WATER_DROPS")) {
			return new WaterDropImageObject(gc, 0, 0);
			
		} else if(objectType.equalsIgnoreCase("SUN")) {
			return new SunImageObject(gc, 0, 0);
			
		} else if(objectType.equalsIgnoreCase("UMBRELLA")) {
			return new UmbrellaImageObject(gc, 0, 0);
			
		}
		
		return null;
	}
}
