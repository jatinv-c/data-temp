package game.fxapp;

import javafx.scene.canvas.Canvas;

public class OxygenCanvasObject extends Canvas implements Prototype {

	OxygenImageObject oxygenImageObject;

	public OxygenCanvasObject(int width, int height, int x, int y) {
		this.setTranslateX(x);
		this.setTranslateY(y);
		this.setHeight(height);
		this.setWidth(width);
		oxygenImageObject = new OxygenImageObject(this.getGraphicsContext2D(), 0, 0);
		oxygenImageObject.update();
	}

	@Override
	public OxygenCanvasObject clone() {
		Object clone = null;

		try {
			clone = super.clone();

		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		((OxygenCanvasObject) clone).oxygenImageObject.update();
		return (OxygenCanvasObject) clone;
	}
}
