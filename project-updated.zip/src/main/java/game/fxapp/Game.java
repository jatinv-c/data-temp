package game.fxapp;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.effect.Glow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

public class Game {

	Pane main;

	public final int TIME_PLANT_NEEDS_WATER_IN_SECONDS = 10;
	public final int NO_OF_TIMES_TO_SHOW_WATER_WARNING = 2;
	public final int SUNLIGHT_NEEDED_SECONDS = 30;
	public final int NO_OF_TIMES_TO_SHOW_SUNLIGHT_WARNING = 2;
	public final int NO_OF_ELEMENTS_NEEDED_FOR_PLANT_TO_MEDIUM_TREE_EVOLUTION = 3;
	public final int NO_OF_ELEMENTS_NEEDED_FOR_MEDIUM_TREE_TO_FULL_TREE_EVOLUTION = 6;
	public final int UMBRELLA_ROTATION_ANGLE = 60;

	Canvas smallPlant;
	Canvas mediumTree;
	Canvas largeTree;
	Canvas wateringCanIV;
	Canvas waterdrops;
	Canvas sunIV;
	Canvas umbrellaIV;

	Image oxygenElement = new Image(new File("oxygen.png").toURI().toString(), 100, 50, false, true);
	Image carbonElement = new Image(new File("carbon.png").toURI().toString(), 100, 50, false, true);

	int noOfOxygenElClicked = 0;
	int noOfCarbonElClicked = 0;

	boolean isOxygenElementShown = false;
	boolean isCarbonElementShown = false;

	boolean isWatering = false;
	boolean isPlantWatered = false;

	// need thread safe integer
	AtomicInteger noOfSecondsPlantIsNotWatered = new AtomicInteger(0);

	AtomicInteger umbrellaAngle = new AtomicInteger(UMBRELLA_ROTATION_ANGLE);
	int noOfSecondsPlantGetsSunlight = 0;

	boolean isMediumTree = false;

	boolean gameOver = false;

	int[][] oxygenCoordiantedArr = { { 370, 70 }, { 220, 250 }, { 50, 400 }, { 550, 90 }, { 530, 430 } };
	int[][] carbonCoordiantedArr = { { 80, 210 }, { 240, 90 }, { 490, 510 }, { 590, 200 }, { 560, 350 } };

	Label warningMsg;
	Label sunlightMsg;

	Canvas oxygenImageCanvas;
	Canvas carbonImageCanvas;
	
	ProgressBar sunlightProgress;
	ProgressBar waterProgress;
	ProgressBar oxygenProgress;
	ProgressBar carbonProgress;

	public Parent createGameUI() {

		main = new Pane();

		BackgroundImage myBI = new BackgroundImage(
				new Image(new File("bg.jpeg").toURI().toString(), 800, 600, false, true), BackgroundRepeat.ROUND,
				BackgroundRepeat.SPACE, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

		main.setBackground(new Background(myBI));

		smallPlant = createAndGetCanvas("PLANT", 100, 100, 360, 400);

		// ************** Watering can starts ***************//
		wateringCanIV = createAndGetCanvas("WATERING_CAN", 150, 120, 160, 400);

		wateringCanIV.setCursor(Cursor.HAND);

		waterdrops = createAndGetCanvas("WATER_DROPS", 100, 100, 300, 400);
		waterdrops.setOpacity(0);
		waterdrops.toFront();

		KeyFrame startFadeOut = new KeyFrame(Duration.seconds(0.5), new KeyValue(waterdrops.opacityProperty(), 1.0));
		KeyFrame endFadeOut = new KeyFrame(Duration.seconds(0.5), new KeyValue(waterdrops.opacityProperty(), 0.0));

		Timeline t1 = new Timeline(startFadeOut, endFadeOut);
		t1.setCycleCount(4);

		wateringCanIV.setOnMouseClicked(e -> {
			if (!isWatering) {

				// set isWatering to true so user cannot click on watering can again till the
				// animation is over
				isWatering = true;

				playWateringSound();

				t1.play();

				t1.setOnFinished(ev -> {
					waterdrops.setOpacity(0);
					isWatering = false;
				});

				isPlantWatered = true;
				noOfSecondsPlantIsNotWatered.set(0);
			}
		});
		// ************** Watering can ends ***************//

		sunIV = createAndGetCanvas("SUN", 100, 100, 0, 0);
		umbrellaIV = createAndGetCanvas("UMBRELLA", 100, 100, 100, 100);

		umbrellaIV.setOnMouseClicked(e -> {

			rotateUmbrella();
		});

		warningMsg = new Label();
		warningMsg.setPrefWidth(300);
		warningMsg.setTranslateX(460);
		warningMsg.setTranslateY(220);
		warningMsg.setWrapText(true);		
		warningMsg.setFont(new Font(20));

		sunlightMsg = new Label();
		sunlightMsg.setPrefWidth(600);
		sunlightMsg.setTranslateX(160);
		sunlightMsg.setTranslateY(10);
		sunlightMsg.setWrapText(true);
		sunlightMsg.setFont(new Font(20));

		Label sunlightLable = new Label("Sunlight");
		sunlightLable.setTranslateX(440);
		sunlightLable.setTranslateY(50);
		sunlightProgress = new ProgressBar(0);
		sunlightProgress.setTranslateX(490);
		sunlightProgress.setTranslateY(50);
		sunlightProgress.setPrefWidth(300);
		sunlightProgress.setStyle("-fx-text-box-border: forestgreen;\r\n" + "  -fx-control-inner-background: black;"
				+ "-fx-accent: yellow;");
		
		
		Label waterLabel = new Label("Water");
		waterLabel.setTranslateX(440);
		waterLabel.setTranslateY(75);
		waterProgress = new ProgressBar(1);
		waterProgress.setTranslateX(490);
		waterProgress.setTranslateY(75);
		waterProgress.setPrefWidth(300);
		waterProgress.setStyle("-fx-text-box-border: forestgreen;\r\n" + "  -fx-control-inner-background: black;"
				+ "-fx-accent: blue;");
		
		
		Label oxygenLabel = new Label("Oxygen");
		oxygenLabel.setTranslateX(440);
		oxygenLabel.setTranslateY(100);
		oxygenProgress = new ProgressBar(0);
		oxygenProgress.setTranslateX(490);
		oxygenProgress.setTranslateY(100);
		oxygenProgress.setPrefWidth(300);
		oxygenProgress.setStyle("-fx-text-box-border: forestgreen;\r\n" + "  -fx-control-inner-background: black;"
				+ "-fx-accent: lightblue;");
		
		Label carbonLabel = new Label("Carbon Dioxide");
		carbonLabel.setTranslateX(400);
		carbonLabel.setTranslateY(125);
		carbonProgress = new ProgressBar(0);
		carbonProgress.setTranslateX(490);
		carbonProgress.setTranslateY(125);
		carbonProgress.setPrefWidth(300);
		carbonProgress.setStyle("-fx-text-box-border: forestgreen;\r\n" + "  -fx-control-inner-background: black;"
				+ "-fx-accent: red;");
		
		
		//add all compnents to the pane
		main.getChildren().addAll(smallPlant, wateringCanIV, waterdrops, sunIV, umbrellaIV, warningMsg, sunlightMsg,
				sunlightLable, sunlightProgress, waterLabel, waterProgress, oxygenLabel, oxygenProgress, carbonLabel, carbonProgress);

//		showElements();
		startRandomElements();
		startPlantWaterCheck();
		startSunlightCheck();
		checkForPlantChange();

		startBackgroundMusic();

		return main;
	}

	/**
	 * Rotate the umbrella to let the plant get sunlight
	 */
	public void rotateUmbrella() {
		Rotate rotate = new Rotate();

		rotate.setPivotX(10);
		rotate.setPivotY(10);

		umbrellaIV.getTransforms().add(rotate);

		if (umbrellaAngle.get() == UMBRELLA_ROTATION_ANGLE) {
			rotate.setAngle(-UMBRELLA_ROTATION_ANGLE);
			umbrellaAngle.set(0);
		} else {
			rotate.setAngle(+UMBRELLA_ROTATION_ANGLE);
			umbrellaAngle.set(UMBRELLA_ROTATION_ANGLE);
		}
	}

	/**
	 * Start displaying the elements randomly on the screen
	 */
	public void startRandomElements() {
		// Oxygen Element
		ElementPrototypeFactory elementPrototypeFactory = new ElementPrototypeFactory();
		Thread oxygenElementThread = new Thread(new Runnable() {
			@Override
			public void run() {
				final AtomicReference<OxygenCanvasObject> oxygenCanvas = new AtomicReference<>();

				while (!gameOver) {
					try {
						Thread.sleep(5000);
						
						boolean oxygenElementsLeftToCollect = true;						
						if(isMediumTree) {
							oxygenElementsLeftToCollect = noOfOxygenElClicked >= NO_OF_ELEMENTS_NEEDED_FOR_PLANT_TO_MEDIUM_TREE_EVOLUTION ? false : true ;
						}else {
							oxygenElementsLeftToCollect = noOfOxygenElClicked >= NO_OF_ELEMENTS_NEEDED_FOR_PLANT_TO_MEDIUM_TREE_EVOLUTION ? false : true ;
						}
						
						if (!isOxygenElementShown && oxygenElementsLeftToCollect) {
							int randomNum = ThreadLocalRandom.current().nextInt(0, oxygenCoordiantedArr.length);

							oxygenCanvas.set(elementPrototypeFactory.getOxygenCanvas(randomNum));
							
							isOxygenElementShown = true;

							oxygenCanvas.get().setOnMouseClicked(e -> {

								main.getChildren().remove(oxygenCanvas.get());

								isOxygenElementShown = false;

								noOfOxygenElClicked++;
								
								if(isMediumTree) {
									oxygenProgress.setProgress((double) noOfOxygenElClicked / NO_OF_ELEMENTS_NEEDED_FOR_MEDIUM_TREE_TO_FULL_TREE_EVOLUTION);
								}else {
									oxygenProgress.setProgress((double) noOfOxygenElClicked / NO_OF_ELEMENTS_NEEDED_FOR_PLANT_TO_MEDIUM_TREE_EVOLUTION);
								}
								

//								checkForPlantChange();

								glowPlant();

							});
							Platform.runLater(() -> {
								main.getChildren().add(oxygenCanvas.get());								
							});
						}
						Thread.sleep(5000);

						// remove element if not clicked on for 5 seconds
						Platform.runLater(() -> {
							main.getChildren().remove(oxygenCanvas.get());
						});
						isOxygenElementShown = false;

					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

				Platform.runLater(() -> {
					if (main.getChildren().contains(oxygenCanvas.get())) {
						main.getChildren().remove(oxygenCanvas.get());
					}
				});
			}
		});

		oxygenElementThread.start();

		//Carbon Element
		Thread carbonElementThread = new Thread(new Runnable() {
			@Override
			public void run() {
				final AtomicReference<CarbonCanvasObject> carbonCanvas = new AtomicReference<>();
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				while (!gameOver) {
					try {
						Thread.sleep(5000);
						
						boolean carbonElementsLeftToCollect = true;						
						if(isMediumTree) {
							carbonElementsLeftToCollect = noOfCarbonElClicked >= NO_OF_ELEMENTS_NEEDED_FOR_PLANT_TO_MEDIUM_TREE_EVOLUTION ? false : true ;
						}else {
							carbonElementsLeftToCollect = noOfCarbonElClicked >= NO_OF_ELEMENTS_NEEDED_FOR_PLANT_TO_MEDIUM_TREE_EVOLUTION ? false : true ;
						}
						
						if (!isCarbonElementShown && carbonElementsLeftToCollect) {
							int randomNum = ThreadLocalRandom.current().nextInt(0, carbonCoordiantedArr.length);

							carbonCanvas.set(elementPrototypeFactory.getCarbonCanvas(randomNum));

							isCarbonElementShown = true;

							carbonCanvas.get().setOnMouseClicked(e -> {								

								main.getChildren().remove(carbonCanvas.get());

								isCarbonElementShown = false;

								noOfCarbonElClicked++;
								
								if (isMediumTree) {
									carbonProgress.setProgress((double) noOfCarbonElClicked
											/ NO_OF_ELEMENTS_NEEDED_FOR_MEDIUM_TREE_TO_FULL_TREE_EVOLUTION);
								} else {
									carbonProgress.setProgress((double) noOfCarbonElClicked
											/ NO_OF_ELEMENTS_NEEDED_FOR_PLANT_TO_MEDIUM_TREE_EVOLUTION);
								}

//								checkForPlantChange();

								glowPlant();
							});

							Platform.runLater(() -> {
								main.getChildren().add(carbonCanvas.get());
							});
						}
						Thread.sleep(5000);

						// remove element if not clicked on for 5 seconds
						Platform.runLater(() -> {
							main.getChildren().remove(carbonCanvas.get());
						});
						isCarbonElementShown = false;

					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				Platform.runLater(() -> {
					if (main.getChildren().contains(carbonCanvas.get())) {
						main.getChildren().remove(carbonCanvas.get());
					}
				});

			}
		});

		carbonElementThread.start();
	}

	public void showElements() {

		for (int i = 0; i < carbonCoordiantedArr.length; i++) {
			ImageView oxygenIV = new ImageView(oxygenElement);
			oxygenIV.setTranslateX(oxygenCoordiantedArr[i][0]);
			oxygenIV.setTranslateY(oxygenCoordiantedArr[i][1]);
			main.getChildren().add(oxygenIV);
		}

		for (int i = 0; i < carbonCoordiantedArr.length; i++) {
			ImageView carbonIV = new ImageView(carbonElement);
			carbonIV.setTranslateX(carbonCoordiantedArr[i][0]);
			carbonIV.setTranslateY(carbonCoordiantedArr[i][1]);
			main.getChildren().add(carbonIV);
		}

	}

	/**
	 * check to see if the plant has been watered periodically
	 */
	public void startPlantWaterCheck() {
		Thread th = new Thread(() -> {
			// wait few seconds before starting the check for water
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			int noOfWarnings = 0;

			while (!gameOver) {
				try {
					Thread.sleep(1000);

					//restart the warning count once the plant is watered
					if (noOfSecondsPlantIsNotWatered.get() == 0) {
						noOfWarnings = 0;
						waterProgress.setProgress(1);
					}
					
					noOfSecondsPlantIsNotWatered.getAndAdd(1);
					waterProgress.setProgress(1 - (double) noOfSecondsPlantIsNotWatered.get() / (TIME_PLANT_NEEDS_WATER_IN_SECONDS * (NO_OF_TIMES_TO_SHOW_WATER_WARNING + 1)));
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				if (noOfSecondsPlantIsNotWatered.get() > 0
						&& noOfSecondsPlantIsNotWatered.get() % TIME_PLANT_NEEDS_WATER_IN_SECONDS == 0) {

					isPlantWatered = false;

					if (noOfWarnings < NO_OF_TIMES_TO_SHOW_WATER_WARNING) {
						System.out.println("The plant has not been watered.");

						Platform.runLater(() -> showMsg("The plant has not been watered."));

						noOfWarnings++;
					} else {
						System.out.println("GAME OVER");
						gameOver = true;

						Platform.runLater(() -> gameOver("The tree did not get enough water"));

					}

				}

			}
		});

		th.start();
	}

	/**
	 * Check to see if the plant is getting proper sunlight or not
	 */
	public void startSunlightCheck() {
		Thread th = new Thread(() -> {
			int noOfWarning = 0;
			while (!gameOver) {		
				//run every 1 second
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
				//check if sunlight is allowed and increment the second counter
				if (umbrellaAngle.get() != UMBRELLA_ROTATION_ANGLE) {
					noOfSecondsPlantGetsSunlight++;
					sunlightProgress.setProgress((double) noOfSecondsPlantGetsSunlight / 30);
				}

				//if more sunlight is allowed than needed, than show warning
				if (noOfSecondsPlantGetsSunlight > SUNLIGHT_NEEDED_SECONDS && noOfSecondsPlantGetsSunlight % 20 == 0) {

					if (noOfWarning > NO_OF_TIMES_TO_SHOW_SUNLIGHT_WARNING) {
						gameOver = true;
						Platform.runLater(() -> gameOver("The tree died due to excessive sunlight."));
					} else {
						noOfWarning++;
						showSunlightMsg();
					}
				}
			}
		});
		th.start();
	}
	
	/**
	 * Check for plant evolution
	 */
	public void checkForPlantChange() {
		Thread th = new Thread(() -> {

			while (!gameOver) {
				try {
					// check every second for tree evolution conditions
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				System.out.println("-----------------------");
				System.out.println(noOfOxygenElClicked);
				System.out.println(noOfCarbonElClicked);
				System.out.println(isPlantWatered);
				System.out.println(noOfSecondsPlantGetsSunlight);
				System.out.println("-----------------------");

				if (!isMediumTree && noOfOxygenElClicked >= NO_OF_ELEMENTS_NEEDED_FOR_PLANT_TO_MEDIUM_TREE_EVOLUTION
						&& noOfCarbonElClicked >= NO_OF_ELEMENTS_NEEDED_FOR_PLANT_TO_MEDIUM_TREE_EVOLUTION
						&& isPlantWatered && noOfSecondsPlantGetsSunlight > SUNLIGHT_NEEDED_SECONDS) {

					isMediumTree = true;
					isPlantWatered = false;
					noOfSecondsPlantGetsSunlight = 0;
					sunlightProgress.setProgress(0);

					noOfOxygenElClicked = 0;
					oxygenProgress.setProgress(0);

					noOfCarbonElClicked = 0;
					carbonProgress.setProgress(0);

					KeyFrame startFadeOut = new KeyFrame(Duration.seconds(0.2),
							new KeyValue(smallPlant.opacityProperty(), 1.0));
					KeyFrame endFadeOut = new KeyFrame(Duration.seconds(2.5),
							new KeyValue(smallPlant.opacityProperty(), 0.0));

					Timeline t1 = new Timeline(startFadeOut, endFadeOut);
					t1.play();
					t1.setOnFinished(et -> {
						main.getChildren().remove(smallPlant);

						mediumTree = createAndGetCanvas("MEDIUM_TREE", 100, 200, 360, 300);

						mediumTree.setOpacity(0);

						main.getChildren().add(mediumTree);
						waterdrops.toFront();

						KeyFrame keyFrame2On = new KeyFrame(Duration.seconds(0.5),
								new KeyValue(mediumTree.opacityProperty(), 0.0));
						KeyFrame endFadeIn = new KeyFrame(Duration.seconds(2.8),
								new KeyValue(mediumTree.opacityProperty(), 1.0));

						Timeline t2 = new Timeline(keyFrame2On, endFadeIn);
						t2.play();
					});

				} else if (isMediumTree
						&& noOfOxygenElClicked >= NO_OF_ELEMENTS_NEEDED_FOR_MEDIUM_TREE_TO_FULL_TREE_EVOLUTION
						&& noOfCarbonElClicked >= NO_OF_ELEMENTS_NEEDED_FOR_MEDIUM_TREE_TO_FULL_TREE_EVOLUTION
						&& isPlantWatered && noOfSecondsPlantGetsSunlight > SUNLIGHT_NEEDED_SECONDS) {

					gameOver = true;

					KeyFrame startFadeOut = new KeyFrame(Duration.seconds(0.2),
							new KeyValue(mediumTree.opacityProperty(), 1.0));
					KeyFrame endFadeOut = new KeyFrame(Duration.seconds(2.5),
							new KeyValue(mediumTree.opacityProperty(), 0.0));

					Timeline t1 = new Timeline(startFadeOut, endFadeOut);
					t1.play();
					t1.setOnFinished(et -> {
						main.getChildren().remove(mediumTree);

						largeTree = createAndGetCanvas("LARGE_TREE", 300, 400, 260, 130);

						largeTree.setOpacity(0);

						main.getChildren().add(largeTree);
						waterdrops.toFront();

						KeyFrame keyFrame2On = new KeyFrame(Duration.seconds(0.5),
								new KeyValue(largeTree.opacityProperty(), 0.0));
						KeyFrame endFadeIn = new KeyFrame(Duration.seconds(2.8),
								new KeyValue(largeTree.opacityProperty(), 1.0));

						Timeline t2 = new Timeline(keyFrame2On, endFadeIn);
						t2.play();

						t2.setOnFinished(e -> {
							Platform.runLater(() -> showMsg("Congratulations!! You Won."));
						});
					});
				}
			}
		});
		th.start();
	}

	/**
	 * Create and return canvas object with image for the requested image type
	 * @param imageType
	 * @param width
	 * @param height
	 * @param x
	 * @param y
	 * @return
	 */
	public Canvas createAndGetCanvas(String imageType, double width, double height, int x, int y) {

		Canvas canvas = new Canvas();

		GameObject imageObject = GameObjectFactory.getGameObject(imageType, canvas.getGraphicsContext2D());

		canvas.setHeight(height);
		canvas.setWidth(width);

		canvas.setTranslateX(x);
		canvas.setTranslateY(y);

		imageObject.update();

		return canvas;
	}

	public void startBackgroundMusic() {
		Thread th = new Thread(() -> {
			Media media = new Media(new File("bg-music.wav").toURI().toString()); 
			MediaPlayer mediaPlayer = new MediaPlayer(media);			
			mediaPlayer.setCycleCount(javafx.scene.media.AudioClip.INDEFINITE);
			mediaPlayer.setVolume(0.5f);
			mediaPlayer.setAutoPlay(true);
			MediaView mediaView = new MediaView(mediaPlayer);
			Platform.runLater(() -> main.getChildren().add(mediaView));
		});
		th.start();
	}

	public void playWateringSound() {
		Thread th = new Thread(() -> {
			Media media = new Media(new File("watering-can-sound.wav").toURI().toString()); 
			MediaPlayer mediaPlayer = new MediaPlayer(media);			
			mediaPlayer.setCycleCount(1);
			mediaPlayer.seek(new Duration(4500));
			mediaPlayer.setStartTime(new Duration(3500));
			mediaPlayer.setAutoPlay(true);						
			MediaView mediaView = new MediaView(mediaPlayer);
			Platform.runLater(() -> main.getChildren().add(mediaView));
		});
		th.start();
	}

	/**
	 * Show game over dialog box
	 * @param msg
	 */
	public void gameOver(String msg) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("Game Over !!!");
		alert.setHeaderText(null);
		alert.setContentText("You have lost the game !!\n" + msg);

		alert.showAndWait();
		try {
			App.setRoot(new Home().createHomeUI());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Show "Not Enough Water" or "You Won" message to the user
	 * @param msg
	 */
	public void showMsg(String msg) {
		KeyFrame startFadeOut = new KeyFrame(Duration.seconds(1.0), new KeyValue(warningMsg.opacityProperty(), 1.0));
		KeyFrame endFadeOut = new KeyFrame(Duration.seconds(6.5), new KeyValue(warningMsg.opacityProperty(), 0.0));

		Timeline t1 = new Timeline(startFadeOut, endFadeOut);

		warningMsg.setText(msg);
		if (warningMsg.getText().toLowerCase().contains("won")) {
			warningMsg.setFont(new Font(35));
			warningMsg.setTextFill(Color.RED);
			t1.setCycleCount(-1);
		}

		Thread th = new Thread(() -> {
			t1.play();
			t1.setOnFinished(e -> {
				Platform.runLater(() -> {
					if (!warningMsg.getText().toLowerCase().contains("won")) {
						warningMsg.setText("");
					}
				});
			});
		});
		th.start();
	}

	/**
	 * Show Sunlight message
	 */
	public void showSunlightMsg() {
		KeyFrame startFadeOut = new KeyFrame(Duration.seconds(1.0), new KeyValue(sunlightMsg.opacityProperty(), 1.0));
		KeyFrame endFadeOut = new KeyFrame(Duration.seconds(6.5), new KeyValue(sunlightMsg.opacityProperty(), 0.0));

		Timeline t1 = new Timeline(startFadeOut, endFadeOut);

		Platform.runLater(() -> {
			sunlightMsg.setText(
					"The plant will die if it will recieve sunlight for too long. Use the umbrella to block the sunlight.");
		});

		Thread th = new Thread(() -> {
			t1.play();
			t1.setOnFinished(e -> {
				Platform.runLater(() -> {
					sunlightMsg.setText("");
				});
			});
		});
		th.start();
	}

	/**
	 * Show plant glow animation when element is clicked
	 */
	public void glowPlant() {
		Glow glow = new Glow();
		glow.setLevel(5);
		Thread th = new Thread(() -> {
			Platform.runLater(() -> {
				if (mediumTree != null && isMediumTree) {
					mediumTree.setEffect(glow);					
				} else {
					smallPlant.setEffect(glow);
				}
			});

			try {
				Thread.sleep(500);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			Platform.runLater(() -> {
				if (mediumTree != null && isMediumTree) {
					mediumTree.setEffect(null);
				} else {
					smallPlant.setEffect(null);
				}
			});
		});
		th.start();
	}
}
