package Project.Planets;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.image.Image;

/**
 * Singleton Class The Singleton class is used to create the planets list and
 * record the high score.
 */
public class Singleton {

    private static Singleton singleton;
    private List<Planet> planetList;
    private int highScore = 0; //initially high score is 0
    private String name = "";

    private Singleton() {
        createPlanets();
    }

    //get the single instance of singleton class
    public static Singleton getInstance() {
        //create the instance if it is null. FIrst time whenever this method is called
        if (singleton == null) {
            singleton = new Singleton();
        }
        return singleton;
    }

    public List<Planet> getPlanetList() {
        return planetList;
    }

    public int getHighScore() {
        return highScore;
    }

    public void setHighScore(int highScore) {
        this.highScore = highScore;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    //add Planet data such as name, image, facts and questions
    private void createPlanets() {

        planetList = new ArrayList<>();
        List<String> questionsList;
        Image image;
        String facts;

        //Mercury
        facts = "- Mercury is the smallest planet in the solar system.\n"
                + "- Mercury is 57.91 million km from the sun.\n"
                + "- Mercury was named after the swift-footed roman messenger god.";
        questionsList = new ArrayList<>();
        questionsList.add("Which planet was named after the swift-footed roman messenger god?");
        questionsList.add("Which planet is 57.91 million km from the sun?");
        questionsList.add("Which planet is the smallest planet in the solar system?");
        image = new Image(new File("Mercury.png").toURI().toString(), 150, 150, false, false);
        Planet mercury = new Planet("Mercury", facts, questionsList, image);
        planetList.add(mercury);

        //Venus
        facts = "- Venus spins clockwise on its axis unlike other planets.\n"
                + "- Venus is 108.2 million km from the sun.\n"
                + "- Venus was named after the roman goddess of love and beauty.";
        questionsList = new ArrayList<>();
        questionsList.add("Which planet was named after the roman goddess of love and beauty?");
        questionsList.add("Which planet is 108.2 million km from the sun?");
        questionsList.add("Which planet spins clockwise on its axis unlike other planets?");
        image = new Image(new File("Venus.png").toURI().toString(), 150, 150, false, false);
        Planet venus = new Planet("Venus", facts, questionsList, image);
        planetList.add(venus);

        //Earth
        facts = "- Earth is 71% water.\n"
                + "- Earth is 149.6 million km from the sun.\n"
                + "- Earth comes from the Old English word 'ertha' meaning ground.";
        questionsList = new ArrayList<>();
        questionsList.add("Which planet comes from the Old English word 'ertha' meaning ground?");
        questionsList.add("Which planet is 149.6 million km from the sun?");
        questionsList.add("Which planet is 71% water?");
        image = new Image(new File("Earth.png").toURI().toString(), 150, 150, false, false);
        Planet earth = new Planet("Earth", facts, questionsList, image);
        planetList.add(earth);

        //Mars
        facts = "- Mars has the tallest mountains in the solar system.\n"
                + "- Mars is 245.17 million km from the sun.\n"
                + "- Mars was named after roman god of War.";
        questionsList = new ArrayList<>();
        questionsList.add("Which planet was named after roman god of War?");
        questionsList.add("Which planet is 245.17 million km from the sun?");
        questionsList.add("Which planet has the tallest mountains in the solar system?");
        image = new Image(new File("Mars.png").toURI().toString(), 150, 150, false, false);
        Planet mars = new Planet("Mars", facts, questionsList, image);
        planetList.add(mars);

        //Saturn
        facts = "- Saturn has 150 moons, more than any other planet.\n"
                + "- Saturn is 1.434 billion km from the sun.\n"
                + "- Saturn was named after the roman god of agriculture and wealth.";
        questionsList = new ArrayList<>();
        questionsList.add("Which planet was named after the roman god of agriculture and wealth?");
        questionsList.add("Which planet is 1.434 billion km from the sun?");
        questionsList.add("Which planet has 150 moons, more than any other planet?");
        image = new Image(new File("Saturn.png").toURI().toString(), 150, 150, false, false);
        Planet saturn = new Planet("Saturn", facts, questionsList, image);
        planetList.add(saturn);

        //Jupiter
        facts = "- Jupiter is the fastest spinning planet in the solar system.\n"
                + "- Jupiter is 778.5 million km from the sun.\n"
                + "- Jupiter was named after the King of the roman gods.";
        questionsList = new ArrayList<>();
        questionsList.add("Which planet was named after the King of the roman gods?");
        questionsList.add("Which planet is 778.5 million km from the sun?");
        questionsList.add("Which planet is the fastest spinning planet in the solar system?");
        image = new Image(new File("Jupiter.png").toURI().toString(), 150, 150, false, false);
        Planet jupiter = new Planet("Jupiter", facts, questionsList, image);
        planetList.add(jupiter);

        //Uranus
        facts = "- Uranus is known as the \"sideways planet\" because it rotates on its side.\n"
                + "- Uranus is 2.871 billion km from the sun.\n"
                + "- Uranus was named after the Greek god of the sky.";
        questionsList = new ArrayList<>();
        questionsList.add("Which planet was named after the Greek god of the sky?");
        questionsList.add("Which planet is 2.871 billion km from the sun?");
        questionsList.add("Which planet is known as the \"sideways planet\" because it rotates on its side?");
        image = new Image(new File("Uranus.png").toURI().toString(), 150, 150, false, false);
        Planet uranus = new Planet("Uranus", facts, questionsList, image);
        planetList.add(uranus);

        //Neptune
        facts = "- Neptune has the strongest winds in the Solar System/ 2100 km/hour.\n"
                + "- Neptune is 4.4756 billion km from the sun.\n"
                + "- Neptune was named after the roman god of the sea.";
        questionsList = new ArrayList<>();
        questionsList.add("Which planet was named after the roman god of the sea?");
        questionsList.add("Which planet is 4.4756 billion km from the sun?");
        questionsList.add("Which planet has the strongest winds in the Solar System/ 2100 km/hour?");
        image = new Image(new File("Neptune.png").toURI().toString(), 150, 150, false, false);
        Planet neptune = new Planet("Neptune", facts, questionsList, image);
        planetList.add(neptune);

    }
}
