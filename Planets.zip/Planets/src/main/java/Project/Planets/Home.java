package Project.Planets;

import java.io.File;
import java.io.IOException;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 *UI Controller for Home page
 */
public class Home {

    //static Scene scene;
    private final int FONT_SIZE = 25;

    public Parent createHomeUI() {

        //VBox will be the Parent container
        VBox vbox = new VBox();

        //HBox Container used for Title Pane
        HBox hboxTitle = new HBox();
        hboxTitle.setAlignment(Pos.CENTER);
        hboxTitle.setBackground(new Background(new BackgroundFill(Color.PURPLE.brighter(), null, null)));

        //label to display title
        Label title = new Label("Planets Quiz");
        title.setFont(Font.font("System", FontWeight.BOLD, FONT_SIZE));
        title.setTextFill(Color.AQUA);
        title.setPadding(new Insets(5, 25, 5, 25));

        //add the title label to title container
        hboxTitle.getChildren().add(title);

        //Button to start the quiz
        Button startButton = new Button("Go To Quiz ->");
        startButton.setBackground(new Background(new BackgroundFill(Color.PURPLE.darker(), null, null)));
        startButton.setTextFill(Color.AQUA);
        startButton.setCursor(Cursor.HAND);
        startButton.setFont(new Font(FONT_SIZE));
        startButton.setPadding(new Insets(5, 25, 5, 25));

        //add button action listener
        startButton.setOnAction(e -> {
            Game game = new Game();
            try {
                //switch to quiz window
                App.setRoot(game.createHomeUI());
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        //add the button to title container
        hboxTitle.getChildren().add(startButton);

        //add the title pane to Parent vbox
        vbox.getChildren().add(hboxTitle);

        //create a grid ane to show question, timer and planets
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10, 10, 10, 10));

        //create a backgorund for the grid pane
        BackgroundImage myBI = new BackgroundImage(new Image(new File("back.jpg").toURI().toString(), grid.getHeight(), grid.getWidth(), false, true),
                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        //then you set to your node
        grid.setBackground(new Background(myBI));

        //create variable to keep track of row and column in the grid
        int row = 0;
        int col = 0;

        //initialize highscore label
        Label highScoreLabel = new Label("High Score : " + Singleton.getInstance().getHighScore());
        highScoreLabel.setTextFill(Color.WHITE);
        highScoreLabel.setFont(new Font(FONT_SIZE));
        highScoreLabel.setPadding(new Insets(5, 0, 5, 0));

        //add the question label to grid pane
        //3 - 4th param - indicates the column span
        //1 - 5th param - indicates the row span
        grid.add(highScoreLabel, 3, row++);

        //create the planets data using planet list and add it to grid pane
        for (Planet planet : Singleton.getInstance().getPlanetList()) {

            //VBox Planet container which will contain a canvas and a button
            VBox vb = new VBox();

            //Create canvas to show the planet image
            Canvas canvas = new Canvas(150, 150);

            //create image object for the planet
            PlanetObject po = new PlanetObject(planet, canvas.getGraphicsContext2D(), 0, 0);
            //paint the planet image
            po.update();

            //add canvas to the vbox
            vb.getChildren().add(canvas);

            //Create a button to show the planet name
            Button planetName = new Button(planet.getName());

            //set the button background as transparent
            planetName.setBackground(Background.EMPTY);
            planetName.setCursor(Cursor.HAND);
            planetName.setFont(new Font(FONT_SIZE));
            planetName.setTextFill(Color.WHITE);

            //add an action listener to the button. It does same task as canvas mouse listener.
            planetName.setOnAction(e -> {
                //show the facts for that planet
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Facts about " + planet.getName());
                alert.setHeaderText(null);
                String content = planet.getFacts();
                alert.setContentText(content);
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.showAndWait();
            });

            //add the button to vbox
            vb.getChildren().add(planetName);

            //set vbox custom padding
            vb.setPadding(new Insets(20, 20, 20, 20));

            //add the vbox to grid
            grid.add(vb, col++, row);

            //if 4 vbox have been added to one row 
            if (col > 3) {
                //reset the col position to one
                col = 0;

                //cahnge the row to next row by incrementing row variable by one
                row++;
            }
        }

        //add the grid pane to Parent vbox once all planets have been added to the grid
        vbox.getChildren().add(grid);

        //return the parent
        return vbox;
    }

}
