package Project.Planets;

import javafx.scene.canvas.GraphicsContext;

/**
 * PlanetsObject Class Used to create the planet image on the UI.
 */
public class PlanetObject extends GameObject {

    //parameterized contructor
    public PlanetObject(Planet planet, GraphicsContext gc, double x, double y) {
        super(gc, x, y);
        super.img = planet.getImage();
    }

}
