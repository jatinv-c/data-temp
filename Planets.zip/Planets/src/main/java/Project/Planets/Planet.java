package Project.Planets;

import java.util.List;
import javafx.scene.image.Image;

/**
 *Model class for storing Planet information
 */
public class Planet {

    private String name;
    private String facts;
    private List<String> questions;
    private Image image;

    public Planet(String name, String facts, List<String> questions, Image image) {
        this.name = name;
        this.facts = facts;
        this.questions = questions;
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getQuestions() {
        return questions;
    }

    public void setQuestions(List<String> questions) {
        this.questions = questions;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public String getFacts() {
        return facts;
    }

    public void setFacts(String facts) {
        this.facts = facts;
    }

}
