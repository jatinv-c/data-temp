package Project.Planets;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicBoolean;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * UI Controller for Game page
 */
public class Game {

    //declare a common font size
    private final int FONT_SIZE = 25;
    private final int NO_OF_QUESTIONS = 10;

    String question; //to store question
    String correctAnswer; //to store correct answer for the question
    String givenAnswer; //store answer given by user
    Set<String> questionsAsked; //store questions that have already been asked
    int score = 0; //store score for current quiz
    int timeLeft; //stores the time left for a question

    //UI Label component declared at global level as they will be used by multiple methods in this class
    Label timerLabel;
    Label questionLabel;

    boolean gotAnswer; //boolean value to indicate if user has answered a question or not

    //use Atomic boolean which is thread safe for storing if current questio is completed before asking next question
    AtomicBoolean nextQuestion = new AtomicBoolean(false);

    /**
     * Create the UI for Game class
     */
    public Parent createHomeUI() {

        //VBox will be the Parent container
        VBox vbox = new VBox();

        //HBox Container used for Title Pane
        HBox hboxTitle = new HBox();
        hboxTitle.setAlignment(Pos.CENTER);
        hboxTitle.setBackground(new Background(new BackgroundFill(Color.PURPLE.brighter(), null, null)));

        //label to display title
        Label title = new Label("Planets Quiz");
        title.setFont(Font.font("System", FontWeight.BOLD, FONT_SIZE));
        title.setTextFill(Color.AQUA);
        title.setPadding(new Insets(5, 25, 5, 25));

        //add the title label to title container
        hboxTitle.getChildren().add(title);

        //Button to start the quiz
        Button startButton = new Button("Click To Start");
        startButton.setBackground(new Background(new BackgroundFill(Color.PURPLE.darker(), null, null)));
        startButton.setTextFill(Color.AQUA);
        startButton.setCursor(Cursor.HAND);
        startButton.setFont(new Font(FONT_SIZE));
        startButton.setPadding(new Insets(5, 25, 5, 25));
        
        //add button action listener
        startButton.setOnAction(e -> {
            //start the quiz
            startGame();
        });

        //add the button to title container
        hboxTitle.getChildren().add(startButton);

        //add the title pane to Parent vbox
        vbox.getChildren().add(hboxTitle);

        //create a grid ane to show question, timer and planets
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10, 10, 10, 10));

        //create a backgorund for the grid pane
        BackgroundImage myBI = new BackgroundImage(new Image(new File("back.jpg").toURI().toString(), grid.getHeight(), grid.getWidth(), false, true),
                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        //then you set to your grid pane
        grid.setBackground(new Background(myBI));

        //create variable to keep track of row and column in the grid
        int row = 0;
        int col = 0;

        //initialize question label
        questionLabel = new Label();
        questionLabel.setTextFill(Color.WHITE);
        questionLabel.setFont(new Font(15));
        questionLabel.setWrapText(true);

        //add the question label to grid pane
        //3 - 4th param - indicates the column span
        //1 - 5th param - indicates the row span
        grid.add(questionLabel, 0, row, 3, 1);

        //initialize timer label
        timerLabel = new Label("Time : --");
        timerLabel.setTextFill(Color.WHITE);
        timerLabel.setFont(new Font(FONT_SIZE));
        timerLabel.setPadding(new Insets(5, 20, 5, 20));
        //add the border to timer label
        timerLabel.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(3, 3, 3, 3))));

        //add the timer label to grid pane
        grid.add(timerLabel, 3, row++);

        //create custom row contraint for the question row as it needs to show complete question text
        RowConstraints rowConstraints = new RowConstraints(50);
        rowConstraints.setPrefHeight(GridPane.USE_COMPUTED_SIZE);
        //set the contraint to the first row in grid pane which is at 0th index
        grid.getRowConstraints().add(rowConstraints);

        //create the planets data using planet list and add it to grid pane
        for (Planet planet : Singleton.getInstance().getPlanetList()) {

            //VBox Planet container which will contain a canvas and a button
            VBox vb = new VBox();

            //User can click either on planet image or button to answer question
            //Create canvas to show the planet image
            Canvas canvas = new Canvas(150, 150);
            canvas.setCursor(Cursor.HAND);

            //add mouse listener to canvas
            canvas.setOnMouseClicked(e -> {
                //set the gotAnswer to true
                gotAnswer = true;

                //save the planet name that user clicked
                givenAnswer = planet.getName();
            });

            //create image object for the planet
            PlanetObject po = new PlanetObject(planet, canvas.getGraphicsContext2D(), 0, 0);
            //paint the planet image
            po.update();

            //add canvas to the vbox
            vb.getChildren().add(canvas);

            //Create a button to show the planet name
            Button planetName = new Button(planet.getName());

            //set the button background as transparent
            planetName.setBackground(Background.EMPTY);

            planetName.setCursor(Cursor.HAND);
            planetName.setId(planet.getName());
            planetName.setFont(new Font(FONT_SIZE));
            planetName.setTextFill(Color.WHITE);
            planetName.setAlignment(Pos.CENTER);
            planetName.setPrefWidth(vb.getPrefWidth());

            //add an action listener to the button. It does same task as canvas mouse listener.
            planetName.setOnAction(e -> {
                //set the gotAnswer to true
                gotAnswer = true;

                //save the planet name that user clicked
                givenAnswer = planet.getName();
            });

            //add the button to vbox
            vb.getChildren().add(planetName);

            //set vbox custom padding
            vb.setPadding(new Insets(20, 20, 20, 20));

            //add the vbox to grid
            grid.add(vb, col++, row);

            //if 4 vbox have been added to one row 
            if (col > 3) {
                //reset the col position to one
                col = 0;

                //cahnge the row to next row by incrementing row variable by one
                row++;
            }
        }

        //add the grid pane to Parent vbox once all planets have been added to the grid
        vbox.getChildren().add(grid);

        //return the parent
        return vbox;
    }

    /**
     * Starts the quiz
     */
    public void startGame() {

        //initialize an empty set to store questions that have been asked
        questionsAsked = new HashSet<>();

        //reset the timer to 10
        timerLabel.setText("Time : 10");

        //Thread to keep track of showing questions and getting answers from user as well as updating timer
        Thread timerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                
                //iterate the for loop for number of questions that should be there in quiz
                for (int i = 1; i <= NO_OF_QUESTIONS; i++) {

                    //to keep track of question no
                    final int questionNo = i;

                    //while loop to make the thread wait until previous question is answered
                    //if nextQuestion is false, than wait. Otherwise, ask the next question
                    while (nextQuestion.get()) {
                        //wait till user answers the previous question or time is up before asking next question
                    }

                    //make the nextQuestion true so that the thread doesnt move to asking another question
                    nextQuestion.set(true);

                    //gotAnswer is false until the user has clicked on an option
                    gotAnswer = false;

                    //get a question
                    question = getQuestion();

                    //Platform.runLater() is used to execute the statements in the run method on the Main Application thread instead of the current thread
                    //Any operation that is used to update UI or access UI controls, need to be executed using Platform.runLater()
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            questionLabel.setText("Q" + questionNo + "." + question);
                        }
                    });

                    //reset the timer to 10
                    timeLeft = 10;

                    //wait for the user to answer or the time to run out
                    while (gotAnswer != true) {

                        //wait for 1 second before decrementing timer by 1 second
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }

                        //if the user has given the answer while we were waiting, break the loop
                        if (gotAnswer) {
                            break;
                        }

                        //decrement the timer
                        --timeLeft;

//                        //using a final time variable to store current time which can be used inside a 
//                        final int time = timeLeft;
                        //to update the timer label on UI
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                timerLabel.setText("Time : " + timeLeft);
                            }
                        });

                        //if no answer is given in 10 seconds, break the loop
                        if (timeLeft == 0) {
                            break;
                        }
                    }

                    /**
                     * once the question has been answered or time his up, show
                     * a dialog box showing the points that the user scored
                     * before asking the next question
                     */
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {

                            //create a dialog object
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setHeaderText(null);

                            //initailize an audio input stream to read audio file
                            AudioInputStream audioInputStream = null;

                            //if user answers the question
                            if (gotAnswer) {
                                //if the answer is correct
                                if (givenAnswer.equals(correctAnswer)) {
                                    //set content of popup to correct answer
                                    alert.setTitle("Correct Answer!!");

                                    //update the palyers score
                                    score += timeLeft;

                                    //load the correct answer sound file
                                    try {
                                        audioInputStream = AudioSystem.getAudioInputStream(new File("correct.wav").getAbsoluteFile());
                                    } catch (UnsupportedAudioFileException | IOException ex) {
                                        ex.printStackTrace();
                                    }
                                } else {
                                    //set content of popup to wrong answer
                                    alert.setTitle("Wrong Answer!!");

                                    //set timeleft to 0 as it is showed in popup to show points for current question
                                    timeLeft = 0;

                                    //load the wrong answer sound file
                                    try {
                                        audioInputStream = AudioSystem.getAudioInputStream(new File("incorrect.wav").getAbsoluteFile());
                                    } catch (UnsupportedAudioFileException | IOException ex) {
                                        ex.printStackTrace();
                                    }
                                }

                                //play the sound after answer
                                try {
                                    Clip clip;
                                    clip = AudioSystem.getClip();
                                    clip.open(audioInputStream);
                                    clip.loop(0);
                                    clip.start();
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                }

                            } else { //if user doesn't answer in 10 seconds
                                alert.setTitle("Time Up!!");
                            }

                            //show the points scored for current question
                            alert.setContentText("You scored " + timeLeft + " points.");

                            //to wait for the user to close the pop-up
                            Optional<ButtonType> result = alert.showAndWait();

                            //print current score on console
                            System.out.println("Score - " + score);

                            //reset the timer
                            timerLabel.setText("Time : 10");

                            //set nextQuestion value to false so the thread can ask next question
                            nextQuestion.set(false);

                            //finish the game after the last question
                            if (questionNo == NO_OF_QUESTIONS) {
                                gameFinish();
                            }
                        }
                    });
                }               

            }
        });

        //set the thread as a daemon thread
        timerThread.setDaemon(true);

        //start the thread
        timerThread.start();
    }

    /**
     * Gets the random question for the quiz
     */
    public String getQuestion() {
        try {
            //get the planet list
            List<Planet> planetList = Singleton.getInstance().getPlanetList();

            //run inside the loop until a new question is found
            while (true) {
                //get a random planet number (between 0 and 7)
                int planetIndex = ThreadLocalRandom.current().nextInt(0, 8);

                //get the planet data for that index
                Planet planet = planetList.get(planetIndex);

                //iterate through the question list
                for (int i = 0; i < planet.getQuestions().size(); i++) {
                    //get a random question number (between 0 and 2)
                    int factIndex = ThreadLocalRandom.current().nextInt(0, 3);

                    //get the question at that index
                    String tempQuestion = planet.getQuestions().get(factIndex);

                    //check if that question is laready asked or not
                    if (!questionsAsked.contains(tempQuestion)) {
                        //if it is not asked, than add it to thte liast of questions that has been asked
                        questionsAsked.add(tempQuestion);

                        //set the correct answer for that question
                        correctAnswer = planet.getName();

                        //return the question
                        return tempQuestion;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        //return empty string in case any exception is thrown
        return "";
    }    

    /**
     * When the quiz is completed
     */
    public void gameFinish() {

        //wait for the last popup to close before giving finsih game popup
//        while (waitForLastDialogToClose) {
//
//        }

        //msg string - in case a player breaks the high score
        String msg = "";
        if (Singleton.getInstance().getHighScore() < score) {
            Singleton.getInstance().setHighScore(score);
            msg += "Congratulations. You have set a new High score.";
        }

        //create the instance for popup dialog
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        //set tile of the popup
        alert.setTitle("Quiz Completed!!");
        //set header to null
        alert.setHeaderText(null);
        //set the message content
        alert.setContentText("Your total score is - " + score + "\n" + msg);

        //create 3 buttons/choices for the user to select what to do next
        ButtonType restartButton = new ButtonType("Restart Quiz"); //take quiz again
        ButtonType homeButton = new ButtonType("Go To Home"); //go back to home page
        ButtonType quitButton = new ButtonType("Quit", ButtonBar.ButtonData.CANCEL_CLOSE); //exit the program

        //add the buttons to the popup
        alert.getButtonTypes().setAll(restartButton, homeButton, quitButton);

        //show the popup and wait for user to select an option
        Optional<ButtonType> result = alert.showAndWait();

        //based on selection, perform different functions
        if (result.get() == restartButton) {
            System.out.println("Restart the game.");
            startGame();
        } else if (result.get() == homeButton) {
            System.out.println("Go to Home.");
            try {
                App.setRoot(new Home().createHomeUI());
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } else {
            System.exit(0);
        }

    }

}
