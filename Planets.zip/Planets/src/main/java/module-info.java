module Project.Planets {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop; //for playing sound while playing quiz

    opens Project.Planets to javafx.fxml;
    exports Project.Planets;
}